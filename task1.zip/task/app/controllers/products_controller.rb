class ProductsController < ApplicationController
  def index
    @products = Product.all  # Fetch all products from the database
  end

  def new
    @product = Product.new  # Create a new, empty product instance for the form
  end

  def edit_stock
    @product = Product.find(params[:id])
  end

  def edit_quantity
    @product = Product.find(params[:id])
  end

  def edit_price
    @product = Product.find(params[:id])
  end

  def destroy
    @product.destroy
    flash[:notice] = "Product deleted successfully!"
    head :no_content
    redirect_to products_path
  end

  def edit
    @product = Product.find(params[:id])
  end

  def show
    @product = Product.find(params[:id])
  end

  def update_product_quantity
    @product = Product.find(params[:id])

    if params[:quantity].present?
      quantity_change = params[:quantity].to_i
      @product.update(quantity: @product.quantity + quantity_change)
      flash[:notice] = "Product quantity updated successfully!"
    else
      flash[:alert] = "Invalid quantity provided. Please enter a new quantity."
    end

    redirect_to edit_stock_path(@product)
  end

  def update_product_price
    @product = Product.find(params[:id])

    if params[:price].present?
      new_price = params[:price].to_d
      @product.update(price: new_price)
      flash[:notice] = "Product price updated successfully!"
    else
      flash[:alert] = "Invalid price provided. Please enter a new price."
    end

    redirect_to edit_stock_path(@product)
  end

  def create
    @product = Product.new(product_params)  # Create a new product with form data
    if @product.save
      redirect_to products_path, notice: "Product created successfully!"
    else
      render :new  # Re-render the new view if product creation fails
    end
  end

  # Similar logic for edit, update, and destroy actions

  private

  def product_params
    params.require(:product).permit(:name, :price, :quantity)
  end
end

# class ProductsController < ApplicationController
#   def index
#   end

#   def new
#   end

#   def create
#   end

#   def edit
#   end

#   def update
#   end

#   def destroy
#   end
# end
