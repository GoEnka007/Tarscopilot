# Rails.application.routes.draw do
  # resources :products
  # get 'products/index'
  # get 'products/new'
  # get 'products/create'
  # get 'products/edit'
  # get 'products/update'
  # get 'products/destroy'
#   # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

#   # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
#   # Can be used by load balancers and uptime monitors to verify that the app is live.
#   get "up" => "rails/health#show", as: :rails_health_check
  
#   # Defines the root path route ("/")
#   # root "posts#index"
# end
require 'rails/engine'

Rails.application.routes.draw do
  resources :products
  get 'products/index'
  get 'products/new'
  get 'products/create'
  get 'products/edit'
  get 'products/update'
  get 'products/destroy'
  resources :products do
    member do
      get 'edit_stock'
      
      # New routes for updating quantity and price
      patch 'update_quantity'
      patch 'update_price'
      
      get 'edit_quantity'
      get 'edit_price'
    end
  end
end
